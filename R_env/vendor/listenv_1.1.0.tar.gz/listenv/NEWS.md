# Version 1.1.0 [2026-10-04]

## Significant Changes

 * `parse_env_subset()` on `x[NULL]` and `x[1, NULL]` now selects zero
   elements - it used to select all elements.
   
 * `parse_env_subset()` on `x[[]]`, `x[[NULL]]`, `x[[integer(0)]]` now
   gives an error as R does for lists - it used to select all elements.
   
## Bug Fixes

 * Growing a list environment with dimensions, e.g. `length(x) <- n`,
   `x[[n]] <- value`, `x[n] <- value`, and `x$name <- value`, where
   `n > length(x)` or `name` is a new element, did not drop the
   dimensions, as done for lists, which left `x` in an invalid state.

 * `x[[i, j]]` on a list environment with dimensions gave an obscure
   error when the subscripts referred to more than one element.

 * `x[[name]]` where `length(name) != 1` gave an obscure error.

 * `x[[NA]]`, `x[[NA_integer_]]` and `x[[NA_real_]]` gave an obscure
   error instead of returning `NULL`, as done for lists.

 * `x[i] <- value` gave an error if `i` contained zeros, e.g. `x[c(0,
   2)] <- value` and `x[0] <- NULL`, instead of ignoring them, as done
   for lists.

 * `x[i] <- value` gave an error if `i` contained negative indices,
   e.g. `x[-1] <- value` and `x[-1] <- NULL`, instead of assigning or
   removing all other elements, as done for lists.

 * `x[i]` did not handle missing values in `i` as done for lists. For
   numeric indices, e.g. `x[c(1, NA)]`, it gave an obscure error, and
   for logical indices, e.g. `x[NA]` and `x[c(TRUE, NA), ]`, it
   silently dropped such elements, instead of returning `NULL` for
   them. Similarly, `x[i] <- value` did not ignore missing indices
   when `value` is of length one, and did not give an error when it
   is longer.

 * Subsetting a list environment did not truncate fractional indices
   toward zero, as done for lists and arrays. For example, `x[-1.5]`
   returned all elements instead of behaving as `x[-1]`, which drops
   the first element. Similarly, `x[1.5, 2.9]` behaved as `x[1, 3]`
   instead of `x[1, 2]`.

 * `parse_env_subset()` on `x[[i, j]]` with dimensions did not give an
   error for zero indices, e.g.  `x[[1, 0]]`, but returned an empty
   target, although it gave an error for `x[[0]]`.

 * `parse_env_subset()` on `x[[i, j]]` with named dimensions returned
   elements `idx` and `exists` with dimnames that should not be there.

 * `parse_env_subset()` on `x[[i, j]]` with more or fewer dimensions
   than subscripts would either give an obscure error or, silently, an
   incorrect index.

 * `parse_env_subset()` did not truncate fractional indices, as done
   for lists and arrays. For example, `x[[1.5]]` gave `idx = 1.5`
   instead of `1`, and `x[[0.5]]` gave an obscure error instead of an
   error on a zero index.

 * `parse_env_subset()` would treat `x[i]` as `x["i"]`, and similarly
   for more dimensions, e.g. `parse_env_subset(x[i, j])`.

 * `parse_env_subset()` on `x[names]` gave an obscure error when
   `length(names) > 1` and some names did not exist.

 * `parse_env_subset()` on `x$name` and `x[["name"]]` would report
   `exists = TRUE` even if `name` did not exist in `x` but in one of
   the parent environments.

 * `parse_env_subset()` treated a `NULL` subset as an empty one, e.g.
   `x[NULL]` and `x[1, NULL]` selected all elements instead of none.
   Also, `x[[]]`, `x[[NULL]]`, and `x[[integer(0)]]`, and similarly
   for more dimensions, e.g. `x[[1, ]]`, did not give an error, as
   done for lists and arrays.

 * `parse_env_subset("1a", envir = x)` gave an error on 'Not a valid
   variable name', although any name is a valid variable name, e.g.
   `x <- listenv("1a" = 1)`.


# Version 1.0.0 [2026-06-21]

## Significant Changes

 * Changed the package license to permissive Apache License (>= 2).


# Version 0.10.1 [2026-03-10]

## Bug Fixes

 * `as.list(x[c(n, 2)])` on a list environment `x` where `n` is out of
   range would return element values in the wrong location.
 
 * `get_variable(x, c(i, j, k, ...))` would return the wrong value for
   list environments with three or more dimensions.

 * `as.listenv(x)` on a list `x` with NULL elements would store them
   as `list(NULL)` instead of `NULL`, causing `as.list(as.listenv(x))`
   to not be identical to `x`.

 * `as.list(x, all.names = FALSE)` on an unnamed list enviroment `x`
   would return an empty list instead of all elements.

 * `x[, i] <- NULL` on a list environment matrix `x` with partial
   dimnames (some dimensions named, others not) would produce an
   error.
   
 * `parse_env_subset(x[i, j])` would produce an error when the list
   environment `x` had named elements and a subscript was out of
   bounds.


# Version 0.10.0 [2025-11-01]

## Deprecated and Defunct

 * `map()` is formally defunct; use `mapping()` instead.


# Version 0.9.1 [2024-01-28]

## Documentation

 * Fix minor syntax issues in help pages.

 
# Version 0.9.0 [2022-12-15]

## New Features

 * Add `aperm()` and `t()` for list-environment arrays.

 * `parse_env_subset()` gained argument `is_variable` to control
   whether or not the inferred element named should be checked if it
   is a valid variable name.

## Internationalization

 * All warning and error messages are now translatable.

## Deprecated and Defunct

 * `map()` is formally deprecated; use `mapping()` instead.

 * Dropped the defunct usage of `listenv(length = n)`, meaning it no
   longer gives an error but instead produces a `listenv` with an
   element named `length`.


# Version 0.8.0 [2019-12-05]

## Significant Changes

 * S3 method `lengths()` for `listenv` is no longer exported.


## New Features

 * Made several error messages more informative.  The downside is that
   those messages are no longer translated (because they are no longer
   aligned with built-in R error messages which have translations).


## Bug Fixes

 * `parse_env_subset(x[1, names])` on a listenv `x` matrix would throw
   error `Error in if (any(i < 0)) { : missing value where TRUE/FALSE
   needed` if one of the elements in `names` specifies a non-existing
   column name.
 
 * `parse_env_subset(x[])` on a listenv `x` would throw an error on
    `Invalid subset: x[]`.
 
 * `parse_env_subset(x[names])` on a listenv `x` would throw an error
   on `length(x) = 2 > 1 in coercion to logical(1)` when
   `length(names) > 1` and `_R_CHECK_LENGTH_1_LOGIC2_=true`.
 
 * `parse_env_subset(x[1,idxs])` on a listenv `x` would throw an error
    on `length(x) = 2 > 1 in coercion to logical(1)` with
    `length(idxs) > 1` and `_R_CHECK_LENGTH_1_LOGIC2_=true`.
 
 * `parse_env_subset(x[[names]])` on a regular environment `x` with
   `length(names) > 1` would not throw an error, whereas `x[[names]]`
   would.
 
 * `parse_env_subset(x[[1]])` on a regular environment `x` would not
   throw an error, whereas `x[[1]]` would.
 
 
# Version 0.7.0 [2018-01-21]
 
## New Features
 
 * Now it is possible to set the dimension on an empty list
   environment without first resizing it with `length()`, e.g. `x <-
   listenv(); dim(x) <- c(2, 3)`.
 
 * Now it is possible to remove multiple elements by assigning NULL,
   e.g.  `x[c(2:3, 10)] <- NULL` and `x[, "B"] <- NULL`.
 
 * Added `lengths()` for list environments.  Requires R (>= 3.3.0).
 
 * `dim_na(x) <- dims`, where `dims` contain exactly one missing
   value, will set the "missing" dimension based on the length of `x`
   and the other dimensions specified, e.g. with `length(x) == 6`,
   `dim_na(x) <- c(2, NA)` will set `dim(x) <- c(2, 3)`.  This works
   for all types of object to which dimensions can be assigned - not
   only list environments.
 
 * Added `is.matrix()`, `is.array()`, `as.vector()`, and `as.matrix()`
   for list environments.
 
 
## Bug Fixes
 
 * `print()` on a named, empty list environment would output an empty
   string.
 
 * Removing an element from a list environment did not remove
   dimensions, e.g. `x$a <- NULL`.
 
 
## Deprecated and Defunct
 
 * Function `map()` has been renamed to `mapping()` and same for the
   corresponding replacement function.  The `map()` and `map<-()`
   functions will soon be deprecated and eventually defunct.
 
 * `x <- listenv(length = n)` is defunct; use `x <- listenv();
   length(x) <- n` instead.
 
 
# Version 0.6.0 [2015-12-27]
 
## New Features
 
 * Added support for multi-dimensional subsetting of list environments
   just as for list.
 
 
## Bug Fixes
 
 * `parse_env_subset(x[[idx]])` for list environment `x` and index
   `idx` claimed `x[[idx]]` existed as long as `idx` in
   `[1,length(x)]`, but it forgot to check if element really existed,
   which may not be true if `x` has been expanded.
 
 
# Version 0.5.0 [2015-10-30]
 
## New Features
 
 * Add support for assigning elements when creating list environment
   similar to how lists work, e.g. `x <- listenv(a = 1, b = 2)`.
 
 * `length(x) <- n` now expand/truncate a list environment.
 
 * Added `unlist()` and `all.equal()` for list environments.
 
 
## Deprecated and Defunct
 
 * Deprecated `x <- listenv(length = n)`; use `x <- listenv();
   length(x) <- n` instead.
 
 
## Bug Fixes
 
 * `as.listenv(x)` would drop NULL elements in `x`.
 
 * `x[idxs]`, `x[name] <- y`, and `x$<name> <- y` would introduce NA
   names for non-named list environments.
 
 
# Version 0.4.0 [2015-08-08]
 
## New Features
 
 * Added `as.listenv()`.
 
 * CONSISTENCY: Assigning NULL now removes element just as lists,
    e.g. `x$a <- NULL`. To assign value NULL, do `x['a'] <-
    list(NULL)`.
 
 * Added support for subsetting with `[()`, which returns another list
   environment, e.g. `x[2:3]`, `x[-1]`, and `x[c(TRUE, FALSE)]`.
 
 * Added `[<-` assignment, e.g. `x['a'] <- 1` and `x[2:3] <- c(3,8)`.
 
 * CLEANUP: Dropped stray debug code.
 
 
# Version 0.3.0 [2015-05-23]
 
## Code Refactorization
 
 * Package no longer depends on other packages.
 
 
# Version 0.2.4 [2015-05-22]
 
## New Features
 
 * Added helper function `parse_env_subset()`.
 
 
# Version 0.2.3 [2015-05-21]
 
## New Features
 
 * `print()` on `listenv` handles empty and no-named `listenv`:s
   better.
 
 
# Version 0.2.2 [2015-05-20]
 
## New Features
 
 * Now `listenv(length = ...)` always allocates internal variables.
 
 
# Version 0.2.1 [2015-05-19]
 
## New Features
 
 * `get_variable()` gained argument `mustExist`.
 
 
# Version 0.2.0 [2015-05-19]
 
## Significant Changes
 
 * Moved list environments from an in-house package to its own package.
 
 
# Version 0.1.4 [2015-05-02]
 
## New Features
 
 * Added `print()` for `listenv`:s.
 
 
## Code Refactorization
 
 * Using `tempvar()` of **R.utils**.


# Version 0.1.0 [2015-02-07]

 * Created.
 
